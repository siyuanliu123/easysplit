//
//  ViewController.swift
//  easysplit
//
//  Created by siyuan liu on 2022/7/18.
//

import UIKit

class ViewController: UIViewController {

    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

